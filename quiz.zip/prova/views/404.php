<div class="apresentacao">
    <div class="error-container">
        <h1>404 - Página não encontrada</h1>
        <p>A página que você está procurando não existe ou foi removida.</p>
        <img src="<?= BASE_URL ?>assets/images/404-error.png" alt="Erro 404" class="error-image">
        <a href="<?= BASE_URL ?>" class="btn btn-primary">Voltar para a página inicial</a>
    </div>
</div>